
// 1   conditions //

let age = 12;

if (age>=18) {
    console.log("Adult");

} else {
    console.log("minor")
}


// 2 loops //


for (let i=0; i< 5; i++) {
    console.log(i);
}



// arrays //

let fruits =["apple", "banana", "mango"];
console.log(fruits[0]);

fruits.push("ornage");


// objects //

let person = {
    name:"alice",
    age:25
};

console.log(person.name);


// variables //

let name = "alice";
var city = "Mumbai";

console.log(city);



// this is a single line comment //

/* this is a multi-line comment */


let x = 25;  //25//

x= x-24;     // 1 //
x = x+ 12;   // 13 //
console.log(x);



// function call //

 console.log("Hello world!");






