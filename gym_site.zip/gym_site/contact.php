<?php include('includes/header.php'); ?>
<style>
    main {
        max-width: 600px;
        margin: 40px auto;
        background: #fff;
        padding: 30px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h1 {
        font-size: 28px;
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin: 15px 0 5px;
    }

    input,
    textarea {
        width: 100%;
        padding: 10px;
        font-size: 16px;
        margin-bottom: 10px;
    }

    button {
        background-color: #111;
        color: #fff;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
    }

    .success {
        color: green;
    }

    .error {
        color: red;
    }
</style>

<main>
    <h1>Contact Us</h1>

    <?php if (isset($_GET['sent']) && $_GET['sent'] === 'true'): ?>
        <p class="success">Your message has been sent successfully!</p>
    <?php elseif (isset($_GET['sent']) && $_GET['sent'] === 'false'): ?>
        <p class="error">There was an error sending your message.</p>
    <?php endif; ?>

    <form action="send_mail.php" method="post">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="message">Message:</label>
        <textarea id="message" name="message" rows="5" required></textarea>

        <button type="submit">Send</button>
    </form>
</main>
<?php include('includes/footer.php'); ?>



