<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
?>
<h2>Welcome to Admin Dashboard</h2>
<p><a href="logout.php">Logout</a></p>

<!-- You can add a table to show messages, etc. -->
