<!-- supplements.php -->
<?php include('includes/header.php'); ?>
<?php
$supplements = [
    [
        "name" => "Protein Powder",
        "desc" => "Whey protein to help muscle growth.",
        "price" => 40,
        "image" => "images/protein.jpg"
    ],
    [
        "name" => "Creatine",
        "desc" => "Improves strength and performance.",
        "price" => 25,
        "image" => "images/creatine.jpg"
    ],
    [
        "name" => "Multivitamins",
        "desc" => "Boosts overall health.",
        "price" => 15,
        "image" => "images/multivitamin.jpg"
    ],
];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Supplements</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Available Supplements</h2>
    <div class="row">
        <?php foreach ($supplements as $item): ?>
            <div class="col-md-4 mt-4">
                <div class="card h-100">
                    <!-- Image section -->
                    <img src="<?= $item['image'] ?>" class="card-img-top" alt="<?= $item['name'] ?>" style="height: 200px; object-fit: cover;">
                    
                    <div class="card-body">
                        <h5 class="card-title"><?= $item['name'] ?></h5>
                        <p class="card-text"><?= $item['desc'] ?></p>
                        <p class="card-text"><strong>Price:</strong> $<?= $item['price'] ?></p>
                        <form action="add_to_cart.php" method="POST">
                            <input type="hidden" name="product_name" value="<?= $item['name'] ?>">
                            <input type="hidden" name="product_price" value="<?= $item['price'] ?>">
                            <button type="submit" class="btn btn-outline-primary">Add to Cart</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="mt-4">
        <a href="cart.php" class="btn btn-secondary">View Cart</a>
    </div>
</div>
</body>
</html>
