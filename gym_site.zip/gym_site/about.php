<?php include('includes/header.php'); ?>
<style>
    .about-header {
        background-color: #e597a5;
        padding: 50px 0;
        text-align: center;
    }

    .about-header h1 {
        font-size: 36px;
        font-weight: bold;
        margin: 0;
        color: #000;
    }

    .about-content {
        max-width: 800px;
        margin: 40px auto;
        text-align: center;
    }

    .about-image {
        width: 100%;
        max-width: 600px;
        margin: 0 auto 30px;
    }

    .about-image img {
        width: 100%;
        height: auto;
        border-radius: 8px;
    }

    .about-text {
        font-size: 18px;
        line-height: 1.8;
        color: #333;
        text-align: left;
        padding: 0 20px;
    }
</style>

<div class="about-header">
    <h1>About us</h1>
</div>

<section class="about-content">
    <div class="about-image">
        <img src="images/group.png" alt="Our team photo">
    </div>
    <div class="about-text">
        <p>We’re a fully distributed team of 85 people living and working in 15 countries around the world. And we’re working to build the best products to help our customers build their brands and grow their businesses on social media.</p>
        <p>We’ve always aimed to do things a little differently. Since the early days, we’ve had a focus on building one of the most unique and fulfilling workplaces by rethinking a lot of traditional practices.</p>
    </div>
</section>

<?php include('includes/footer.php'); ?>
