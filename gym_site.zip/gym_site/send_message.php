<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name    = htmlspecialchars($_POST['name']);
    $email   = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $message = htmlspecialchars($_POST['message']);

    $to      = "carterslade940@example.com";  // Change this to your real email
    $subject = "New Contact Form Message";
    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";
    $body    = "Name: $name\nEmail: $email\n\nMessage:\n$message";

    if (mail($to, $subject, $body, $headers)) {
        header("Location: contact.php?sent=true");
    } else {
        header("Location: contact.php?sent=false");
    }
    exit();
}
?>
