<?php include('includes/header.php'); ?>
<main>
    <h1>Our Services</h1>
    <ul>
        <li>Personal Training</li><br><br>
        <li>Group Fitness Classes</li><br><br>
        <li>Yoga & Pilates</li><br><br>
        <li>Weight Training</li><br><br>
        <li>Cardio Equipment</li><br><br>
        <li>Nutrition Counseling</li><br><br>
    </ul>

    <h2 style="margin-top: 50px;">Workout Programs</h2>
    <div class="services-grid">
        <div class="service-card">
            <img src="images/abs.png" alt="Abs Workouts">
            <h3>Abs Workouts</h3>
        </div>
        <div class="service-card">
            <img src="images/cardio.png" alt="Cardio Workouts">
            <h3>Aerobics & Cardio</h3>
        </div>
        <div class="service-card">
            <img src="images/Body tone.png" alt="Body Tone Workouts">
            <h3>Body Tone & Conditioning</h3>
        </div>
        <div class="service-card">
            <img src="images/combat.png" alt="Combat Sports Classes">
            <h3>Combat Sports</h3>
        </div>
        <div class="service-card">
            <img src="images/core.png" alt="Core Workouts">
            <h3>Core Workouts (dance)</h3>
        </div>
        <div class="service-card">
            <img src="images/dance (4).png" alt="Dance Classes">
            <h3>Gym and Dumbbelss</h3>
        </div>
    </div>
</main>
<?php include('includes/footer.php'); ?>



