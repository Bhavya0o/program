<?php include('includes/header.php'); ?>
<main>
    <h1>Welcome to FitZone Gym</h1>
    <p>Get fit, stay strong, and join our vibrant community of health enthusiasts.</p>
    <img src="images/gym.jpg" alt="Gym Image" width="100%">
</main>
<?php include('includes/footer.php'); ?>









