<?php
session_start();
include('includes/header.php');
include('db.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $items = json_encode($_SESSION['cart']);
    $total = 0;

    foreach ($_SESSION['cart'] as $item) {
        $total += $item['price'] * $item['quantity'];
    }

    $stmt = $conn->prepare("INSERT INTO orders (customer_name, customer_email, items, total_amount) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssd", $name, $email, $items, $total);
    $stmt->execute();
    $stmt->close();

    // Clear cart after order
    unset($_SESSION['cart']);
    echo "<h2>Thank you! Your order has been placed.</h2>";
    include('includes/footer.php');
    exit();
}
?>

<h1>Checkout</h1>
<form method="post">
    <label>Name:</label><br>
    <input type="text" name="name" required><br><br>

    <label>Email:</label><br>
    <input type="email" name="email" required><br><br>

    <button type="submit">Place Order</button>
</form>

<?php include('includes/footer.php'); ?>
