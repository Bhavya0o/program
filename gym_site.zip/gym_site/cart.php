<?php
session_start();
include('includes/header.php');
?>

<h1>Your Cart</h1>

<?php
if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0): ?>
    <p>Your cart is empty.</p>
<?php else: ?>
    <table border="1" cellpadding="10">
        <tr>
            <th>Product</th><th>Price</th><th>Quantity</th><th>Total</th>
        </tr>
        <?php
        $grandTotal = 0;
        foreach ($_SESSION['cart'] as $item):
            $total = $item['price'] * $item['quantity'];
            $grandTotal += $total;
        ?>
        <tr>
            <td><?= $item['name'] ?></td>
            <td>₹<?= $item['price'] ?></td>
            <td><?= $item['quantity'] ?></td>
            <td>₹<?= $total ?></td>
        </tr>
        <?php endforeach; ?>
        <tr>
            <td colspan="3"><strong>Grand Total</strong></td>
            <td>₹<?= $grandTotal ?></td>
        </tr>
    </table>
<?php endif; ?>

<a href="supplements.php">Continue Shopping</a>
<?php include('includes/footer.php'); ?>
<?php if (count($_SESSION['cart']) > 0): ?>
    <br>
    <a href="checkout.php"><button>Proceed to Checkout</button></a>
<?php endif; ?>
