<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
include('includes/header.php');
?>

<h2>Welcome, <?php echo $_SESSION['username']; ?>!</h2>
<p>This is your gym dashboard.</p>
<a href="logout.php">Logout</a>

<?php include('includes/footer.php'); ?>
