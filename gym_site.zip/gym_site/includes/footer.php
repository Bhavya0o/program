<hr>
<footer>
    <p>&copy; 2025 FitZone Gym. All rights reserved.</p>
    <footer style="background-color:#f3f2ef; padding: 40px; font-family: Arial, sans-serif; font-size: 14px; color: #666;">
    <div style="max-width: 1200px; margin: auto; display: flex; flex-wrap: wrap; justify-content: space-between;">
        <div style="flex: 1 1 200px; margin: 10px;">
            <strong>About</strong><br><br>
            Accessibility<br><br>
            Careers<br><br>
            Marketing Solutions<br><br>
            Talent Solutions<br><br>
            Professional Community Policies
        </div>
        <div style="flex: 1 1 200px; margin: 10px;">
            <strong>Privacy & Terms</strong><br><br>
            Ad Choices<br><br>
            Advertising<br><br>
            Sales Solutions<br><br>
            Mobile<br><br>
            Small Business<br><br>
            Safety Center
        </div>
        <div style="flex: 1 1 200px; margin: 10px;">
            <strong>Support</strong><br><br>
            Questions? Visit our <a href="#">Help Center</a>.<br><br><br>
            Manage your account and privacy: <a href="#">Settings</a><br><br>
            <a href="#">Learn more about Recommended Content</a>
        </div>
        <div style="flex: 1 1 200px; margin: 10px;">
            <strong>Select Language</strong><br><br><br>
            English (English)
        </div>
    </div>

    <div style="text-align:center; margin-top: 30px; font-size: 12px; color: #999;">
        FitZone Corporation © 2025
    </div>
</footer>


</footer>
</body>
</html>
