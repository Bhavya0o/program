<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FitZone Gym</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
    <h2>FitZone Gym</h2>
    <nav>
        <a href="index.php">Home</a> |
        <a href="about.php">About</a> |
        <a href="services.php">Services</a> |
        <a href="contact.php">Contact</a>
        <a href="supplements.php">supplements</a>
    
        <?php if (isset($_SESSION['username'])): ?>
            <!-- If the user is logged in, show Dashboard and Logout -->
            <a href="dashboard.php">Dashboard</a> |
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <!-- If the user is not logged in, show Login and Register links -->
            <a href="login.php">Login</a> |
            <a href="register.php">Register</a>
        <?php endif; ?>
     </nav>
</header>
<hr>
