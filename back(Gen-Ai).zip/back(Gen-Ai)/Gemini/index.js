const express = require("express");
const cors = require("cors");
require("dotenv").config();

const { GoogleGenerativeAI } = require("@google/generative-ai");

const app = express();
app.use(cors());
app.use(express.json());

// Gemini init
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({
  model: "models/gemini-2.5-flash"
});

// Prompt builder
function buildPrompt(topic, totalMarks, totalQue, type) {
  const marksPerQuestion = totalMarks / totalQue;

  return `
You are an expert exam paper setter.

Topic: ${topic}
Total Marks: ${totalMarks}
Number of Questions: ${totalQue}
Question Type: ${type}

Rules:
- Generate ONLY ${type} questions
- Each question must carry ${marksPerQuestion} marks
- Return ONLY valid JSON (no markdown, no explanation)

JSON format:
{
  "topic": "${topic}",
  "totalMarks": ${totalMarks},
  "questions": [
    {
      "id": "Q1",
      "type": "${type}",
      "marks": ${marksPerQuestion},
      "question": "string",
      "options": ["A","B","C","D"],
      "answer": "string"
    }
  ]
}
`;
}





// API
app.post("/api/generate-test", async (req, res) => {
  try {
    const { topic, totalMarks, totalQuestions, type } = req.body;

    if (!topic || !totalMarks || !totalQuestions || !type) {
      return res.status(400).json({
        error: "All fields are required"
      });
    }

   const prompt = buildPrompt(
  topic,
  Number(totalMarks),
  Number(totalQuestions),
  type.toLowerCase()
);

    const result = await model.generateContent({
      contents: [
        {
          role: "user",
          parts: [{ text: prompt }]
        }
      ],
      generationConfig: {
        responseMimeType: "application/json"
      }
    });

    const text = result.response.text();
    const data = JSON.parse(text);

    res.json(data);

  } catch (err) {
    console.error("Server Error:", err);
    res.status(500).json({
      error: "Failed to generate paper"
    });
  }
});

// Server
app.listen(5000, () => {
  console.log("✅ Server running on http://localhost:5000");
});