const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

canvas.width = 400;
canvas.height = 400;

const box = 20;
let snake = [{ x: 200, y: 200 }];
let direction = "RIGHT";
let food = {
    x: Math.floor(Math.random() * (canvas.width / box)) * box,
    y: Math.floor(Math.random() * (canvas.height / box)) * box,
};

document.addEventListener("keydown", changeDirection);

function changeDirection(event) {
    const key = event.keyCode;
    if (key === 37 && direction !== "RIGHT") direction = "LEFT";
    else if (key === 38 && direction !== "DOWN") direction = "UP";
    else if (key === 39 && direction !== "LEFT") direction = "RIGHT";
    else if (key === 40 && direction !== "UP") direction = "DOWN";
}

function drawFood() {
    ctx.fillStyle = "red";
    ctx.fillRect(food.x, food.y, box, box);
}

function drawSnake() {
    ctx.fillStyle = "black";
    snake.forEach((segment) => {
        ctx.fillRect(segment.x, segment.y, box, box);
    });
}
function updateGame() {
    let head = { ...snake[0] };

    // Move in the current direction
    if (direction === "LEFT") head.x -= box;
    else if (direction === "RIGHT") head.x += box;
    else if (direction === "UP") head.y -= box;
    else if (direction === "DOWN") head.y += box;

    // Wrap around when touching the wall
    if (head.x < 0) head.x = canvas.width - box; // Left border
    else if (head.x >= canvas.width) head.x = 0; // Right border
    if (head.y < 0) head.y = canvas.height - box; // Top border
    else if (head.y >= canvas.height) head.y = 0; // Bottom border

    // Check for self-collision
    if (snake.some(segment => segment.x === head.x && segment.y === head.y)) {
        alert("Game Over!");
        snake = [{ x: 200, y: 200 }];
        direction = "RIGHT";
        return;
    }

    snake.unshift(head);

    // Check if snake eats food
    if (head.x === food.x && head.y === food.y) {
        food = {
            x: Math.floor(Math.random() * (canvas.width / box)) * box,
            y: Math.floor(Math.random() * (canvas.height / box)) * box,
        };
    } else {
        snake.pop();
    }
}


function gameLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawFood();
    drawSnake();
    updateGame();
}

setInterval(gameLoop, 100);
